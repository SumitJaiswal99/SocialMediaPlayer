//
//  GivenRatingViewController.swift
//  SocialMediaPlayer
//
//  Created by iPHTech 29 on 17/04/23.
//

import UIKit
import Cosmos

enum UserDefaultsKeys : String {
    case countRatingKey
    case VideosID
}
class GivenRatingViewController: UIViewController {
    
    @IBOutlet weak var videoIDForRatingLabel: UILabel!
    var videoIDForRating = ""
    var countRatingKeyValues =  ""
    var titleName: String = ""
    @IBOutlet weak var slidder: UISlider!
    @IBOutlet weak var countRating: CosmosView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countRating.settings.fillMode = .half
        slidder.minimumValue = 0
        slidder.maximumValue=9
        

    }
   
  
    @IBAction func saveratingAction(_ sender: Any) {
        print("Storing data..")
        let data = MovieDetails(movieId: videoIDForRating, rating: Double(countRatingKeyValues) ?? 0.0, isFavourite: false,title: titleName)
        UserDefaultsManager.shared.addData(movieRating: data)
        let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "MoviesListViewController") as? MoviesListViewController
        self.navigationController?.pushViewController(vc!, animated: true)
    }

//    @IBAction func retrieveratingACtion(_ sender: Any) {
//        print("Fetching data..")
////        print(UserDefaults.standard.string(forKey: UserDefaultsKeys.VideosID.rawValue)!)
//        if let data = UserDefaultsManager.shared.getData(movieId: videoIDForRating){
//            print(data)
//        }
//        else {
//
//        }
        
 //   }
  
    @IBAction func giveRatingAction(_ sender: UISlider) {
        countRating.rating = Double(sender.value)
        countRatingKeyValues = "\(Double(round(10 * countRating.rating) / 10))"
        print(countRatingKeyValues)
        print(countRating)
        
    }
    
}

