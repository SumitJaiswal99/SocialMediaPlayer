//
//  FavouriteCollectionViewCell.swift
//  SocialMediaPlayer
//
//  Created by iPHTech 29 on 19/04/23.
//

import UIKit

class FavouriteCollectionViewCell: UICollectionViewCell {
    
}
